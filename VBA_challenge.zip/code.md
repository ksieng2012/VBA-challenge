Sub stock_check()

    'Fill out header
    Range("I1") = "Ticker"
    Range("j1") = "Yearly Change"
    Range("k1") = "Percent Change"
    Range("l1") = "Total Stock Volume per 1000"
    
    'define row and colum
    Dim lRow As Long
    
    'find range of row
    lRow = Cells(Rows.Count, 1).End(xlUp).Row
    'MsgBox (lRow)
    
    'define ticker
    Dim ticker As String
    
    'define place holder for the row in summary table
    Dim RowLoc As Integer
    RowLoc = 2
    
    'define year change and beg_year and end_year
    'where year_change=end_year-beg_year
    'Dim year_change As Long
    Dim beg_year As Long
    'Dim end_year As Long
    
    
    'define begining and end of year price
    Dim begin_year As Long
    begin_year = 2
    
    'define total annual volum
    Dim total_vol As Double
    
    'declare volum per 1000 array
    Dim vol() As Variant
    
    
    'loop through all tickers and group the ticker
    
    For i = 2 To lRow
    
            ' check next row vs current row
        If Cells(i + 1, 1).Value <> Cells(i, 1).Value Then
            
            ' set ticker name
            ticker = Cells(i, 1).Value
            'print out ticker
            Range("I" & RowLoc).Value = ticker
            
            'calculate year change
            'year_change = end_year - beg_year
            Range("J" & RowLoc).Value = (Cells(i, 6).Value - Cells(begin_year, 3).Value)
            'Range("J" & RowLoc).NumberFormat = "0.00"
            
            'change cell color base on value of year_change
            If Range("J" & RowLoc).Value < 0 Then
                Range("J" & RowLoc).Interior.ColorIndex = 3
            Else
                Range("J" & RowLoc).Interior.ColorIndex = 4
            End If
                
            
            'Calculat and print percent year change
            If Range("C" & begin_year).Value <> 0 Then
               Range("K" & RowLoc).Value = Format((Range("J" & RowLoc).Value / (Range("C" & begin_year).Value)), "percent")
            Else
                Range("K" & RowLoc).Value = 0
            End If
            
            
            'print out total volum
            total_vol = total_vol + Range("G" & i).Value * 0.001
            Range("L" & RowLoc).Value = Format(total_vol, "#,###.00")
                
            'Reset total volum
            total_vol = 0
            
            'set next row in summary table
            RowLoc = RowLoc + 1
            
            'set new begining of the year for the next ticker
            begin_year = i + 1
            
                    
            
            Else
            
            'Calculate total volume per 1000
            total_vol = total_vol + Range("G" & i).Value * 0.001
            'MsgBox (i)
            
        End If
    
    Next i
    
    ' Challenge 1. Your solution will also be able to return the stock with the "Greatest % increase",
    ' "Greatest % decrease" and "Greatest total volume". The solution will look as follows:
   ' fill out headers
    Range("O1") = "Ticker"
    Range("P1") = "Value"
    Range("N2") = "Greatest % increase"
    Range("N3") = "Greatest % decrease"
    Range("N4") = "Greatest total volume"
    'declare max_change, min_change and max_vol
   Dim max_change As Double
   Dim min_change As Double
   Dim max_vol As Double
   
   'declare last row of ticker
   Dim tic_row As Long
   tic_row = Cells(Rows.Count, 9).End(xlUp).Row

   
   'initiate max and min value
    max_change = Range("K2").Value
    min_change = Range("K2").Value
    max_vol = Range("L2").Value
    'define index for each value
    Dim max_change_i As Integer
    Dim min_change_i As Integer
    Dim max_vol_i As Integer
    max_change_i = 0
    min_change_i = 0
    max_vol_i = 0
   

   'loop through summary table to find max and min
    For i = 3 To tic_row
    
       'Condition for max_change
        If Range("K" & i).Value > max_change Then
          max_change = Range("K" & i).Value
          max_change_i = i
          'Range("O2").Value = Range("I" & i).Value
        End If
        'Condition for min_change
        If Range("K" & i).Value < min_change Then
           min_change = Range("K" & i).Value
           min_change_i = i
        End If
       'Condition for max_vol
        If Range("L" & i).Value > max_vol Then
           max_vol = Range("L" & i).Value
           max_vol_i = i
        End If
        
   Next i
   
   'test to make sure that the index is not zero and print out the infos
   If max_change_i = 0 Then
    Range("O2") = Range("I2").Value
   Else
    Range("o2") = Range("I" & max_change_i)
   End If
   
   If min_change_i = 0 Then
    Range("O3") = Range("I2").Value
   Else
    Range("o3") = Range("I" & min_change_i)
   End If
      
   If max_vol_i = 0 Then
    Range("O4") = Range("I2").Value
   Else
    Range("o4") = Range("I" & max_vol_i)
   End If
   
   Range("P2").Value = Format(max_change, "percent")
   Range("P3").Value = Format(min_change, "percent")
   Range("P4").Value = Format(max_vol, "#,###.00")
   
    
End Sub

